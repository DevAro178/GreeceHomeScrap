<?php

include('./functions.php');

// $Products = GetProducts('https://www.indomio.gr/en/pwlhsh-katoikies/aigeira/');
// print_r($Products);

function Main($url)
{
    // Calling the CurlCall function to get response data for the first page
    $response = CurlCallToAPI($url);
    // Storing resultant array in $data array
    $data = ScrapingProducts($response);
    // Getting all keys of $data Array
    $keys = array_keys($data);
    // 
    foreach ($keys as $key) {
        $internalArray = array();
        //Checking if the value is not array
        if (!is_array($data[$key])) {
            //Calling CurlCall Function to get the source code 
            $response = CurlCallToAPI($data[$key]);
            $internalArray = ScrapingProducts($response);
            $internalKeys = array_keys($internalArray);
            foreach ($internalKeys as $internalKey) {
                if (!is_array($internalArray[$internalKey])) {
                    $Products = GetProducts($internalArray[$internalKey]);
                    $internalArray[$internalKey] = $Products;
                }
            }
            // replacing existing link with array of child page URLS
            $data[$key] = $internalArray;
        }
    }
}

// Main('https://www.indomio.gr/en/');


// $nums = array();
// $nums[] = 0;
// $nums[] = 1;
// $nums[] = 2;
// $nums[] = 3;
// $nums[] = 4;
// foreach ($nums as $num) {
//     echo ($num);
//     echo ("<br>");
//     break;
// }