<?php

include('./ProductDetailsClass.php');
include('./simple_html_dom.php');

$data = array();

function CurlCallToAPI($url)
{
    $curl = curl_init();
    $encodedURL = urlencode($url);
    $CurlURL = "https://api.webscrapingapi.com/v1?url=";
    $CurlURL .= $encodedURL;
    $CurlURL .= "&api_key=X80HlWTDGksS0CRy3nCEYNFxufRaTWn0&device=desktop&proxy_type=datacenter&render_js=1&wait_until=domcontentloaded";
    curl_setopt_array($curl, [
        CURLOPT_URL => $CurlURL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
    ]);
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        //echo "cURL Error #:" . $err;
    } else {
        return $response;
    }
}
function ScrapingProducts($response)
{
    $internalArray = array();
    require_once './simple_html_dom.php';
    $html = new simple_html_dom(); // Instantiate the DOM parser object
    $html->load($response);

    $items = $html->find('.nd-listMeta__item');
    foreach ($items as $item) {
        $titletags = $item->find('.nd-listMeta__link');
        foreach ($titletags as $titletag) {
            $innerHtml = $titletag->innertext;
            $link = $titletag->href;
            $internalArray[$innerHtml] = $link;
        }
    }
    return $internalArray;
}
function GetProducts($url)
{
    $ProductArray = array();
    $paginationNum = GetPaginationNumber($url);
    for ($i = 1; $i <= $paginationNum; $i++) {
        $PaginationUrl = $url . "?pag=" . $i;
        $response = CurlCallToAPI($PaginationUrl);
        $html = new simple_html_dom();
        $html->load($response);
        $products = $html->find('.nd-list__item.in-realEstateResults__item');
        foreach ($products as $product) {
            $links = $product->find('.in-card__title'); // Corrected selector
            foreach ($links as $link) {
                $ProductArray[] = GetProductDetails($link->href);
                // print_r($ProductArray);
                // exit();
            }
        }
        break;
    }
    return $ProductArray;
}

function GetPaginationNumber($url)
{
    $response = CurlCallToAPI($url);
    $html = new simple_html_dom();
    $html->load($response);
    $paginationList = $html->find('.in-pagination__list', 0);
    if ($paginationList) {
        $children = $paginationList->children();
        if ($children) {
            $lastElement = end($children);
            reset($children); // Reset the array pointer after using end()
            $innerText = trim($lastElement->plaintext);
            return $innerText;
        }
    }
}

function GetProductDetails($Producturl)
{
    //declaring all the block scoped variables here
    $ProductDetails = array(); // Clearing the entire array
    $ProductDetails = array(
        'imageLinks' => array(), // Array to store image links
        'name' => '', // String to store the name
        'address' => array(), // Array to store addresses
        'description' => '', // String to store the description
        'Price' => '', // String to store the price
        'Rooms' => '', // String to store the number of rooms
        'Surface' => '', // String to store the surface area
        'Bathroom' => '', // String to store the number of bathrooms
        'floor' => '', // String to store the floor
        'Features' => array(), // Array to store features
        'Expenses' => array(), // Array to store expenses
        'EnergyEfficiency' => array() // Array to store energy efficiency details
    );
    $imagesArray = array();
    $AdressArray = array();
    $Features = array();
    $Expenses = array();
    $EnergyEfficiency = array();

    //Using CurlCall method to get the response
    $response = CurlCallToAPI($Producturl);
    $html = new simple_html_dom();
    $html->load($response);

    // getting image links
    $images = $html->find('.nd-slideshow__item');
    foreach ($images as $internal) {
        $img = $internal->find('img', 0);
        if ($img) {
            $imagesArray[] = $img->src;
        }
    }
    $ProductDetails['imageLinks'] = $imagesArray;



    // Getting Title
    $title = $html->find('.in-titleBlock__title');
    foreach ($title as $internal) {
        $ProductDetails['name'] = $internal->innertext;
        //echo ($internal->innertext);
        //echo ('<br>');
    }


    // Getting Address
    $location = $html->find('.in-titleBlock__link');
    foreach ($location as $internal) {
        $spans = $internal->find('span'); // Find all <span> tags within $internal
        foreach ($spans as $span) {
            $AdressArray[] = $span->innertext;
        }
        $ProductDetails['address'] = $AdressArray;
        print_r($AdressArray);
        //echo ('<br>');
    }


    // Getting Price
    $Price = $html->find('.in-detail__mainFeaturesPrice');
    foreach ($Price as $internal) {
        $ProductDetails['Price'] = $internal->innertext;
        //echo ($internal->innertext);
        //echo ("<br>");
    }

    // Getting Number of rooms
    $rooms = $html->find('[aria-label="rooms"]');
    foreach ($rooms as $internal) {
        $divs = $internal->find('.in-feat__data');
        foreach ($divs as $div) {
            if (!empty($div)) {
                $innerText = $div->plaintext;
                //echo $innerText;
                //echo ("<br>");
                $ProductDetails['Rooms'] = $innerText;
            }
        }
    }

    // Getting Number of surface
    $Surface = $html->find('[aria-label="surface"]');
    foreach ($Surface as $internal) {
        $divs = $internal->find('.in-feat__data');
        foreach ($divs as $div) {
            if (!empty($div)) {
                $innerText = $div->plaintext;
                //echo $innerText;
                //echo ("<br>");
                $ProductDetails['Surface'] = $innerText;
            }
        }
    }

    // Getting Number of bathroom
    $bathroom = $html->find('[aria-label="bathroom"]');
    foreach ($bathroom as $internal) {
        $divs = $internal->find('.in-feat__data');
        foreach ($divs as $div) {
            if (!empty($div)) {
                $innerText = $div->plaintext;
                //echo $innerText;
                //echo ("<br>");
                $ProductDetails['Bathroom'] = $innerText;
            }
        }
    }

    // Getting Number of floor
    $floor = $html->find('[aria-label="floor"]');
    foreach ($floor as $internal) {
        $divs = $internal->find('.in-feat__data');
        foreach ($divs as $div) {
            if (!empty($div)) {
                $innerText = $div->plaintext;
                //echo $innerText;
                //echo ("<br>");
                $ProductDetails['floor'] = $innerText;
            }
        }
    }
    //echo ("------------------");
    // Getting Description
    $Description = $html->find('.in-readAll.in-readAll--lessContent');
    foreach ($Description as $internal) {
        $divs = $internal->find('div');
        foreach ($divs as $div) {
            if (!empty($div)) {
                $innerText = $div->outertext;
                //echo $innerText;
                //echo ("<br>");
                $ProductDetails['description'] = $innerText;
            }
        }
    }
    //echo ("------------------");

    // in-realEstateFeatures__list
    $table = $html->find('.in-realEstateFeatures__list', 0); // Assuming you have selected the <dl> element using find() method
    if ($table) {
        $dtTags = $table->find('dt');
        $ddTags = $table->find('dd');


        for ($i = 0; $i < count($dtTags); $i++) {
            $key = trim($dtTags[$i]->plaintext);
            $value = trim($ddTags[$i]->plaintext);

            if ($key === 'other features') {
                $spanTags = $ddTags[$i]->find('span');
                $spanArray = array();
                foreach ($spanTags as $span) {
                    $spanArray[] = $span->plaintext;
                }
                $value = $spanArray;
            }
            $Features[$key] = $value;
        }

        // print_r($Features);
        $ProductDetails['Features'] = $Features;
    }
    //echo ("<br>");
    //echo ('-----------------------');
    $table = $html->find('.in-realEstateFeatures__list', 1); // Assuming you have selected the <dl> element using find() method
    if ($table) {
        $dtTags = $table->find('dt');
        $ddTags = $table->find('dd');


        for ($i = 0; $i < count($dtTags); $i++) {
            $key = trim($dtTags[$i]->plaintext);
            $value = trim($ddTags[$i]->plaintext);
            $Expenses[$key] = $value;
        }

        // print_r($Expenses);
        $ProductDetails['Expenses'] = $Expenses;
    }
    //echo ("<br>");
    //echo ('-----------------------');
    $table = $html->find('.in-realEstateFeatures__list', 2); // Assuming you have selected the <dl> element using find() method
    if ($table) {
        $dtTags = $table->find('dt');
        $ddTags = $table->find('dd');


        for ($i = 0; $i < count($dtTags); $i++) {
            $key = trim($dtTags[$i]->plaintext);
            $value = trim($ddTags[$i]->plaintext);
            $EnergyEfficiency[$key] = $value;
        }

        // print_r($EnergyEfficiency);
        $ProductDetails['EnergyEfficiency'] = $EnergyEfficiency;
    }
    // print_r($ProductDetails);

    $html->clear();
    return $ProductDetails;
}

function saveTofile($url, $fileName)
{
    //This functioned is defined if need to save the API response into an HTML file and view it 
    $response = CurlCallToAPI($url);
    $html = new simple_html_dom();
    $html->load($response);

    // Save the HTML to a file
    $file = './';
    $file .= $fileName;
    $file .= '.html';

    file_put_contents($file, $html);
    $html->clear();
}
