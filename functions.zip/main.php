<?php

$data=array();
function ScrapingProducts() {
    global $data;
	require_once './simple_html_dom.php';
    $curl = curl_init();
	curl_setopt_array($curl, [
		CURLOPT_URL => "https://api.webscrapingapi.com/v1?url=https%3A%2F%2Fwww.indomio.gr%2Fen%2F&api_key=X80HlWTDGksS0CRy3nCEYNFxufRaTWn0&device=desktop&proxy_type=datacenter&render_js=1&wait_until=domcontentloaded",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
	]);
	$response = curl_exec($curl);
	$err = curl_error($curl);
	curl_close($curl);
	if ($err) {
		echo "cURL Error #:" . $err;
	} else {
		$html = new simple_html_dom(); // Instantiate the DOM parser object
		$html->load($response);
		$items = $html->find('.nd-listMeta__item');
		foreach ($items as $item) {
			$titletags=$item->find('.nd-listMeta__link');
            $X=0;
			foreach ($titletags as $titletag) {
				$innerHtml=$titletag->innertext;
				$link=$titletag->href;
                $data[$innerHtml]=$link;
			}
		}
	}
}
ScrapingProducts();
echo(count($data)); 
// foreach ($data as $innerHtml => $link) {
//     echo "Inner HTML: " . $innerHtml . "<br>";
//     echo "Link: " . $link . "<br>";
//     echo "<br>";
// }

?>